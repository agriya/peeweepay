<?php
class IonoLicenseHandler
	{

		public $home_url_site =  'http://customers.agriya.com';
		public $home_url_port = 80;
		public $home_url_iono = '/sales/remote.php';
        public $user_defined_string = 'f258410f387e';
        public $comm_terminate = true;
		public $license_terminate = true;
        public $product_license_id = 275; //provide the product license id to be validated
        public $product_id = 144; //provide the product id to be validated


        public function setErrorTexts()
        	{
        		$this->error_text['disabled'] = '<p><strong>License Error:</strong> Your license is disabled. </p>';
				$this->error_text['suspended'] = '<p><strong>License Error:</strong> Your license has been suspended. </p>';
				$this->error_text['expired'] = '<p><strong>License Error:</strong> Your license has expired. </p>';
				$this->error_text['exceeded'] = '<p><strong>License Error:</strong> You have reached the maximum number of installs allowed. </p>';
				$this->error_text['invalid_user'] = '<p><strong>License Error:</strong> Invalid license key. </p>';
				$this->error_text['invalid_code'] = '<p><strong>License Error:</strong> Invalid license status code. </p>';
				$this->error_text['invalid_hash'] = '<p><strong>License Error:</strong> Invalid communication hash. </p>';
				$this->error_text['wrong_product'] = '<p><strong>License Error:</strong> The license key you provided is not for this product. </p>';
				$this->error_text['integrated_product_license_missing'] = '<p><strong>License Error in Integration:</strong> The license key for the integrated product is not provided.</p>';
				$this->error_text['integrated_product_id_missing'] = '<p><strong>License Error in Integration:</strong> The product id given for integration is invalid. Upgrade your files.</p>';
			}



        public function ionLicenseHandler($license_key, $request_type)
        	{
        		// Check that the $license_key provided is for this product
				if (!empty($this->product_id))
					{
						$key_parts = explode('-', $license_key);
						if ((!isset($key_parts[2]) OR $key_parts[2] != $this->product_id))
						{
							return $this->error_text['wrong_product']; // 'wrong_product';
						}
					}
					// Check that the $license_key provided is for this license type of the product
				if (!empty($this->product_license_id))
					{
						$key_parts = explode('-', $license_key);
						$product_license_id = array(substr(md5($this->product_license_id), 0, 8));

						if (!in_array($key_parts[4], $product_license_id))
						{
							return $this->error_text['wrong_product']; // 'wrong_product';

						}
					}
				$host =  $_SERVER['HTTP_HOST'];
				if(strcasecmp('www.', substr($_SERVER['HTTP_HOST'],0,4)) == 0)
					{
						$host = substr($_SERVER['HTTP_HOST'],4);
					}

				// Build request
				$request = 'remote=licensenew&type='.$request_type.'&license_key='.urlencode(base64_encode($license_key));
				$request .= '&host_ip='.urlencode(base64_encode($_SERVER['SERVER_ADDR'])).'&host_name='.urlencode(base64_encode($host));
				$request .= '&hash='.urlencode(base64_encode(md5($request)));

				$request = $this->home_url_site.$this->home_url_iono.'?'.$request;

				// New cURL resource
				$ch = curl_init();

				// Set options
				curl_setopt($ch, CURLOPT_URL, $request);
				curl_setopt($ch, CURLOPT_PORT, $this->home_url_port);
				curl_setopt($ch, CURLOPT_HEADER, false);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_USERAGENT, 'iono (www.olate.co.uk/iono)');

				// Execute
				$content = curl_exec($ch);

				// Close
				curl_close($ch);

				if (!$content)
					{
						return 'Unable to communicate with Iono';
					}

				// Split up the content
				$content = explode('-', $content);
				$status = $content[0];
				$hash = $content[1];
				if ($hash == md5($this->user_defined_string.$host))
					{
						//return $status;
						switch ($status)
							{
								case 0: // Disabled
									$err_msg = $this->error_text['disabled'];
									unset($home_url_site, $home_url_iono, $user_defined_string, $request, $header, $return, $fpointer, $content, $status, $hash);

									break;
								case 1: // Ok
									$err_msg = '';
									break;
								case 2: // Suspended
									$err_msg = $this->error_text['suspended'];
									unset($home_url_site, $home_url_iono, $user_defined_string, $request, $header, $return, $fpointer, $content, $status, $hash);

									break;
								case 3: // Expired
									$err_msg = $this->error_text['expired'];
									unset($home_url_site, $home_url_iono, $user_defined_string, $request, $header, $return, $fpointer, $content, $status, $hash);

									break;
								case 4: // Exceeded allowed installs
									$err_msg =  $this->error_text['exceeded'];
									unset($home_url_site, $home_url_iono, $user_defined_string, $request, $header, $return, $fpointer, $content, $status, $hash);

									break;
								case 10: // Invalid user ID or license key
									$err_msg = $this->error_text['invalid_user'];
									unset($home_url_site, $home_url_iono, $user_defined_string, $request, $header, $return, $fpointer, $content, $status, $hash);

									break;
								default: // Invalid status code
									$err_msg =  $this->error_text['invalid_code'];
									unset($home_url_site, $home_url_iono, $user_defined_string, $request, $header, $return, $fpointer, $content, $status, $hash);

									break;
							}
						return $err_msg;

					}
				else
					{
						return $this->error_text['invalid_hash'];
					}

			}
	}
?>