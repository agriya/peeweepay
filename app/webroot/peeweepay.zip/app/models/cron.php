<?php
class Cron extends AppModel
{
    var $name = 'Cron';
    var $useTable = false;
}
?>