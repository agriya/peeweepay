<?php
class AdaptiveIpnLog extends AppModel
{
    var $name = 'AdaptiveIpnLog';
    function __construct($id = false, $table = null, $ds = null) 
    {
        parent::__construct($id, $table, $ds);
    }
}
?>